#!/bin/bash
cd /home/ec2-user/service-app-backend
npm install
