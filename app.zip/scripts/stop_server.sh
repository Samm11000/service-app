#!/bin/bash
pm2 stop service-app || echo "App not running"
